const express = require('express');
const path = require('path');
const kuponRoutes = require('./routes/kupon');
const authRoutes = require('./routes/auth');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Routing API
app.use('/api/kupon', kuponRoutes);
app.use('/api/auth', authRoutes);

// Routing ke frontend
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.redirect('/login.html');
});

app.listen(port, () => {
  console.log(`✅ Server aktif di http://localhost:${port}`);
});
