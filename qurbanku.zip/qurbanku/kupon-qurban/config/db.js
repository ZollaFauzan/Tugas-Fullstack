// config/db.js
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,       // contoh: 'postgres'
  host: process.env.DB_HOST,       // contoh: 'localhost'
  database: process.env.DB_NAME,   // contoh: 'kupon_qurban'
  password: process.env.DB_PASS,   // contoh: 'passwordbaru'
  port: process.env.DB_PORT        // contoh: 5432
});

module.exports = pool;
