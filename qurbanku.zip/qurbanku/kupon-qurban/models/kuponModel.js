const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const getAllKupon = async () => {
  const res = await pool.query('SELECT * FROM kupons ORDER BY created_at DESC');
  return res.rows;
};

const getKuponByNomor = async (nomor_antrian) => {
  const res = await pool.query('SELECT * FROM kupons WHERE nomor_antrian = $1', [nomor_antrian]);
  return res.rows[0];
};

const createKupon = async (nama_penerima, nomor_antrian) => {
  const res = await pool.query(
    'INSERT INTO kupons (nama_penerima, nomor_antrian) VALUES ($1, $2) RETURNING *',
    [nama_penerima, nomor_antrian]
  );
  return res.rows[0];
};

const updateStatusKupon = async (nomor_antrian, status) => {
  const res = await pool.query(
    'UPDATE kupons SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE nomor_antrian = $2 RETURNING *',
    [status, nomor_antrian]
  );
  return res.rows[0];
};

module.exports = {
  getAllKupon,
  getKuponByNomor,
  createKupon,
  updateStatusKupon,
};
