// public/js/dashboard.js
const kuponForm = document.getElementById('kuponForm');
const namaInput = document.getElementById('nama');
const kuponList = document.getElementById('kuponList');
const qrSection = document.getElementById('qrSection');
const qrCodeBox = document.getElementById('qrCode');

const API_BASE = '/api/kupon';

kuponForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const nama = namaInput.value.trim();
  if (!nama) return alert('Nama tidak boleh kosong!');

  const nomor = 'KRB2025-' + Math.floor(Math.random() * 10000).toString().padStart(4, '0');

  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nama_penerima: nama, nomor_antrian: nomor })
  });

  const data = await res.json();
  if (res.ok) {
    namaInput.value = '';
    qrSection.classList.remove('hidden');
    qrCodeBox.innerHTML = '';

    new QRCode(qrCodeBox, {
      text: data.nomor_antrian,
      width: 128,
      height: 128
    });

    fetchKupons();
  } else {
    alert('Gagal membuat kupon');
  }
});

async function fetchKupons() {
  const res = await fetch(API_BASE);
  const data = await res.json();
  kuponList.innerHTML = '';
  data.forEach((kupon) => {
    const row = `<tr>
      <td class="px-4 py-2">${kupon.nomor_antrian}</td>
      <td class="px-4 py-2">${kupon.nama_penerima}</td>
      <td class="px-4 py-2">
        <span class="${kupon.status === 'sudah_diambil' ? 'status-sudah' : 'status-belum'}">
          ${kupon.status}
        </span>
      </td>
    </tr>`;
    kuponList.innerHTML += row;
  });
}

// Load QR Code library
const qrScript = document.createElement('script');
qrScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
document.body.appendChild(qrScript);

window.onload = fetchKupons;
