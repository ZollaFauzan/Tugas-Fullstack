// public/js/scanner.js

let scannerActive = false;

function startScanner() {
  if (scannerActive) return;
  scannerActive = true;
  alert("Simulasi: Scanner dimulai. (Fitur kamera akan ditambahkan dengan plugin seperti html5-qrcode)");
  // Placeholder: tampilkan input manual
  const input = prompt("Masukkan nomor kupon hasil scan QR:");
  if (input) {
    validateKupon(input);
  }
  scannerActive = false;
}

function stopScanner() {
  scannerActive = false;
  alert("Scanner dihentikan.");
}

async function validateKupon(nomor) {
  const res = await fetch(`/api/kupon/${nomor}`);
  if (!res.ok) return alert("Kupon tidak ditemukan!");
  const kupon = await res.json();

  if (kupon.status === 'sudah_diambil') {
    alert("⚠️ Kupon sudah digunakan.");
    return;
  }

  const confirmUse = confirm(`Valid: ${kupon.nama_penerima}. Tandai sudah diambil?`);
  if (confirmUse) {
    const update = await fetch(`/api/kupon/${nomor}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'sudah_diambil' })
    });

    if (update.ok) {
      alert("✅ Kupon valid. Silakan ambil daging.");
    } else {
      alert("❌ Gagal mengupdate status kupon.");
    }
  }
}
