const express = require('express');
const router = express.Router();
const pool = require('../app');

// Ambil semua kupon
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM kupons ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil data kupon' });
  }
});

// Ambil kupon berdasarkan nomor_antrian
router.get('/:nomor_antrian', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM kupons WHERE nomor_antrian = $1', [req.params.nomor_antrian]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Kupon tidak ditemukan' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil kupon' });
  }
});

// Buat kupon baru
router.post('/', async (req, res) => {
  const { nama_penerima, nomor_antrian } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO kupons (nama_penerima, nomor_antrian) VALUES ($1, $2) RETURNING *',
      [nama_penerima, nomor_antrian]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat kupon' });
  }
});

// Ubah status kupon
router.put('/:nomor_antrian', async (req, res) => {
  const { status } = req.body;
  try {
    const result = await pool.query(
      'UPDATE kupons SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE nomor_antrian = $2 RETURNING *',
      [status, req.params.nomor_antrian]
    );
    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Kupon tidak ditemukan' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Gagal mengubah status' });
  }
});

module.exports = router;
